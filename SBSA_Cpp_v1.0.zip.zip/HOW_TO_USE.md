# 📘 How to Use the SBSA (Size-Based Slot Allocation) C++ Demo

This project demonstrates the SBSA model in C++, offering a constant-time alternative to traditional B-tree/skip-list structures for mapping files or tasks into ordered slots.

---

## 📂 Files

- `sbsa.cpp` – Core class implementing the SBSA logic
- `main.cpp` – Example usage: mapping size-classed items with thickness and width

---

## 🧰 Requirements

- A C++ compiler (GCC, Clang, MSVC, etc.)
- C++11 or later

---

## 🛠 Compilation

To compile both files into an executable:

```bash
g++ main.cpp -o sbsa_demo
```

---

## ▶️ Running the Demo

After compiling:

```bash
./sbsa_demo
```

### ✅ Expected Output

```
Mapped: slot 2, thickness 2, width 3.5
Mapped: slot 4, thickness 0, width 1
```

---

## 📖 What It Does

The program simulates a system that maps a file into a position using:
- **Slot** — based on size class (e.g., `4KB`, `16KB`)
- **Thickness** — stackable layer index
- **Width** — floating-point size for dynamic width

This forms a 3D address:  
**(slot index, layer, width)**

---

## 🧠 Extend This

You can expand this for:
- File systems or memory allocation models
- Task priority mapping and scheduling
- Real-time log or message channel partitioning

---

## 📝 Example Use

In `main.cpp`:
```cpp
auto pos = sbsa.map_file("4KB", 2, 3.5);
// → slot 2, thickness 2, width 3.5
```

Try modifying the size class, thickness, or width to simulate different scenarios.

---

## 🔒 License

MIT — free to use and modify.
Created by **Aaron Cattell** with ChatGPT-assisted development.
