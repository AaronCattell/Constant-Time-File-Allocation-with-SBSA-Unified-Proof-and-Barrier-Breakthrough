#include "sbsa.cpp"

int main() {
    std::vector<std::string> size_classes = {"1KB", "2KB", "4KB", "8KB", "16KB", "32KB"};
    SBSA sbsa(size_classes);

    try {
        auto pos = sbsa.map_file("4KB", 2, 3.5);
        std::cout << "Mapped: slot " << pos.slot
                  << ", thickness " << pos.thickness
                  << ", width " << pos.width << std::endl;

        auto pos2 = sbsa.map_file("16KB", 0, 1.0);
        std::cout << "Mapped: slot " << pos2.slot
                  << ", thickness " << pos2.thickness
                  << ", width " << pos2.width << std::endl;

    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}
