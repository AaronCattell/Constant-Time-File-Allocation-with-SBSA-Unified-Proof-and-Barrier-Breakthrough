#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>
#include <stdexcept>

class SBSA {
private:
    std::unordered_map<std::string, int> slots;

public:
    SBSA(std::vector<std::string> size_classes) {
        for (size_t i = 0; i < size_classes.size(); ++i) {
            slots[size_classes[i]] = static_cast<int>(i);
        }
    }

    struct FilePosition {
        int slot;
        int thickness;
        float width;
    };

    FilePosition map_file(const std::string& size_class, int thickness, float width) {
        if (slots.find(size_class) == slots.end()) {
            throw std::invalid_argument("Invalid size class: " + size_class);
        }
        return { slots[size_class], thickness, width };
    }
};
