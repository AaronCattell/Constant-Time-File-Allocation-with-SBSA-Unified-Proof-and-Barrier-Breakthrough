File Mapping Core – Quantized Slot Allocation System
This module implements a core utility for mapping files to storage or logical representations based on quantized size classes, width, and thickness values. It is designed to support tunable configuration and ensure inputs are validated and normalized according to system constraints.

📦 Overview
The core concept revolves around mapping a file's physical or logical properties (size_class, thickness, and width) into a tuple format:

scss
Copy
Edit
(slot_index, quantized_thickness, quantized_width)
This mapping supports consistent alignment, quantization, and classification of files for further processing or allocation in memory/storage systems.

🧮 Size Classes
Defined size classes (expandable as needed):

python

size_classes = ['1KB', '2KB', '4KB', '8KB']
Internally, each class is mapped to a unique slot index:

python

slots = {'1KB': 0, '2KB': 1, '4KB': 2, '8KB': 3}
⚙️ Configuration Parameters
These constants define the physical or logical limits and quantization behavior:

Width
MIN_WIDTH = 0.01 – Minimum valid width (e.g., 10 bytes)

MAX_WIDTH = 1_000_000

QUANTUM = 0.05 – Smallest granularity for width quantization

Thickness
MIN_THICKNESS = 0

MAX_THICKNESS = 1_000_000

THICKNESS_QUANTUM = 5 – Thickness values rounded to nearest multiple of 5


🔧 Function: map_file(size_class, thickness, width)
Arguments:

size_class (str): One of the predefined size classes

thickness (float/int): Must be real, finite, and quantized to THICKNESS_QUANTUM

width (float/int): Must be real, finite, and quantized to QUANTUM

Returns:
python

(slot_index, quantized_thickness, quantized_width)

Example:
python

map_file('2KB', thickness=6.2, width=1.03)
# Output: (1, 5, 1.05)

🚫 Input Validation & Errors
The function enforces:

Valid size_class (must exist in slots)

width and thickness must be numeric, finite, and within configured bounds

Values are quantized to their nearest configured step (QUANTUM or THICKNESS_QUANTUM)

Raises:

ValueError for out-of-bound values or unknown size classes

TypeError for non-numeric input types

✅ Example Usage
python
Copy
Edit
file1 = map_file('2KB', thickness=6.2, width=1.03)   # (1, 5, 1.05)
file2 = map_file('4KB', thickness=14.9, width=2.498) # (2, 15, 2.5)
📌 Notes
To extend supported size_classes, simply update the list and slots dictionary accordingly.

This module is adaptable for both physical layout systems and abstract allocation schemes requiring discretized input.