size_classes = ['1KB', '2KB', '4KB', '8KB']
slots = {s: i for i, s in enumerate(size_classes)}  # Ensure this is updated if size_classes are extended

# Configuration parameters (tunable per system design and physical constraints)
MIN_WIDTH = 0.01         # Minimum allowed width (e.g., 10 bytes)
MAX_WIDTH = 1e6          # Maximum allowed width
QUANTUM = 0.05           # Width quantization step

MIN_THICKNESS = 0
MAX_THICKNESS = 1e6
THICKNESS_QUANTUM = 5    # Thickness quantization step

def quantize(value, quantum):
    """Round value to the nearest multiple of quantum."""
    return round(value / quantum) * quantum

def map_file(size_class, thickness, width):
    slot = slots.get(size_class)
    if slot is None:
        raise ValueError(f"Invalid size class: {size_class}")

    # Validate and quantize width
    if not isinstance(width, (int, float)):
        raise TypeError("Width must be a number")
    if width == float('inf') or width != width:
        raise ValueError("Width must be a finite, real number")
    width = quantize(width, QUANTUM)
    if not (MIN_WIDTH <= width <= MAX_WIDTH):
        raise ValueError(f"Width {width} out of bounds")

    # Validate and quantize thickness
    if not isinstance(thickness, (int, float)):
        raise TypeError("Thickness must be a number")
    if thickness == float('inf') or thickness != thickness:
        raise ValueError("Thickness must be a finite, real number")
    thickness = int(quantize(thickness, THICKNESS_QUANTUM))
    if not (MIN_THICKNESS <= thickness <= MAX_THICKNESS):
        raise ValueError(f"Thickness {thickness} out of bounds")

    return (slot, thickness, width)

# Example usage
file1 = map_file('2KB', thickness=6.2, width=1.03)   # (1, 5, 1.05)
file2 = map_file('4KB', thickness=14.9, width=2.498) # (2, 15, 2.5)