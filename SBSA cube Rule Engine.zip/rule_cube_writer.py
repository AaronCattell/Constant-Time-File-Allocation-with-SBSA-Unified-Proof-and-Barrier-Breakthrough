import json
from pathlib import Path
import time

class RuleCubeWriter:
    def __init__(self, root="cube_rules"):
        self.root = Path(root)

    def write_fact(self, rule_id, step, category, logic_or_data):
        timestamp = int(time.time())
        z_map = {"input": 0, "rule": 1, "output": 2}
        z_index = z_map.get(category, 3)

        payload = {
            "id": rule_id,
            "type": category,
            "step": step,
            "timestamp": timestamp,
            "data": logic_or_data
        }

        faces = {
            'z1': (rule_id, step), 'z2': (rule_id, step),
            'x1': (step, z_index), 'x2': (step + 1, z_index),
            'y1': (rule_id, z_index), 'y2': (rule_id, z_index + 1)
        }

        for axis, (a, b) in faces.items():
            path = self.root / f"{axis}/{a}_{b}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(payload, f)
