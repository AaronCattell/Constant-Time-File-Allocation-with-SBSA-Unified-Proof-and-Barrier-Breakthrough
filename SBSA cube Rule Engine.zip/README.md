# SBSA Rule Engine (Cube-Based)

This prototype uses SBSA Cube logic to store logic programming rules and facts across 3D spatial dimensions:

- X = Rule ID
- Y = Trigger / Timestamp
- Z = Category: input, rule, output

Each rule is stored across 6 files for constant-time retrieval.

## Files

- `rule_cube_writer.py` — writes rules to cube
- `rule_cube_query.py` — reads rules by type or time
- `example_rule_flow.py` — runs a simple logic flow
- `cube_rules/` — SBSA-style directory with JSON facts

## Run

```bash
python example_rule_flow.py
```

Then explore the `cube_rules/` directory to inspect logic structure.
