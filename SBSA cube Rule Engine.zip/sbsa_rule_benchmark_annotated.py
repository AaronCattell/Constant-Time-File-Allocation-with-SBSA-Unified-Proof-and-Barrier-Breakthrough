import matplotlib.pyplot as plt

# Example benchmark times (replace with your actual numbers)
flat_time = 0.006  # Flat list retrieval time (in seconds)
sbsa_time = 0.001  # SBSA Cube retrieval time (in seconds)

# Plot
plt.figure(figsize=(8, 5))
bars = plt.bar(["Flat Log", "SBSA Cube"], [flat_time, sbsa_time], color=["gray", "blue"])
plt.ylabel("Retrieval Time (seconds)")
plt.title("Rule Retrieval Benchmark: Flat vs SBSA Cube")

# Annotate bars with time and performance labels
for bar, label in zip(bars, ["slower", "faster"]):
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, height + 0.0002, f"{height:.4f}s\n({label})",
             ha='center', va='bottom', fontsize=10)

plt.tight_layout()
plt.savefig("sbsa_rule_retrieval_benchmark_annotated.png")
plt.show()
