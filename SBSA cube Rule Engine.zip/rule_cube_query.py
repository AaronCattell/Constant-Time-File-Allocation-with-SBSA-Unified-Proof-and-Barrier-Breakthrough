import json
from pathlib import Path

class RuleCubeQuery:
    def __init__(self, root="cube_rules"):
        self.root = Path(root)

    def get_by_category(self, category):
        z_map = {"input": "z1", "rule": "z2", "output": "z3"}
        z_folder = z_map.get(category)
        if not z_folder:
            return []
        folder = self.root / z_folder
        return [json.load(open(f)) for f in folder.rglob("*.json")]

    def get_by_step(self, step):
        results = []
        folder = self.root / "x1"
        for f in folder.rglob(f"{step}_*.json"):
            try:
                results.append(json.load(open(f)))
            except:
                continue
        return results
