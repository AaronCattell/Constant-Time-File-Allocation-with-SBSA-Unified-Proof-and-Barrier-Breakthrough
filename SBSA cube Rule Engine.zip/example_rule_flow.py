from rule_cube_writer import RuleCubeWriter
import time

cube = RuleCubeWriter()

# Add input
cube.write_fact("r1", 1, "input", "sensor_clear")

# Add rule
cube.write_fact("r1", 1, "rule", "IF sensor_clear THEN move_forward")

# Add output
cube.write_fact("r1", 1, "output", "move_forward")
