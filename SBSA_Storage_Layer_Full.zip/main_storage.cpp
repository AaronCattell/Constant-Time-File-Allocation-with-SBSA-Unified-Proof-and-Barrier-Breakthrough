#include "sbsa_storage.cpp"

int main() {
    std::vector<std::string> size_classes = {"1KB", "2KB", "4KB", "8KB", "16KB", "32KB"};
    SBSAStorage sbsa(size_classes);

    std::string data = "This is file content.";
    std::string read_back;

    try {
        sbsa.write("4KB", 2, 3.5, data);
        read_back = sbsa.read("4KB", 2, 3.5);
        std::cout << "Read from SBSA slot: " << read_back << std::endl;
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}
