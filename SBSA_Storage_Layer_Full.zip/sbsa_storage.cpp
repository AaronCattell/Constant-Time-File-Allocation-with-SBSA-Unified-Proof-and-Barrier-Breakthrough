#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <stdexcept>
#include <filesystem>

class SBSAStorage {
private:
    std::unordered_map<std::string, int> slots;

public:
    SBSAStorage(std::vector<std::string> size_classes) {
        for (size_t i = 0; i < size_classes.size(); ++i) {
            slots[size_classes[i]] = static_cast<int>(i);
        }
    }

    std::string get_path(const std::string& size_class, int layer, float width) {
        if (slots.find(size_class) == slots.end()) {
            throw std::invalid_argument("Invalid size class: " + size_class);
        }

        int slot = slots[size_class];
        std::ostringstream path;
        path << "storage/slot_" << slot << "/layer_" << layer << "/file_" << width << ".txt";
        return path.str();
    }

    void write(const std::string& size_class, int layer, float width, const std::string& content) {
        std::string path = get_path(size_class, layer, width);
        std::filesystem::create_directories(std::filesystem::path(path).parent_path());

        std::ofstream out(path);
        if (!out) throw std::runtime_error("Failed to open file for writing");
        out << content;
        out.close();
    }

    std::string read(const std::string& size_class, int layer, float width) {
        std::string path = get_path(size_class, layer, width);

        std::ifstream in(path);
        if (!in) throw std::runtime_error("File not found");
        std::stringstream buffer;
        buffer << in.rdbuf();
        return buffer.str();
    }
};
