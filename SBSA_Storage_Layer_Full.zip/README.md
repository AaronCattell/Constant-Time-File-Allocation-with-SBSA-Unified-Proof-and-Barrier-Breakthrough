# 🗄️ SBSA Storage Layer (C++ Demo)

This demo adds real disk-based storage to the SBSA (Size-Based Slot Allocation) model.

## 🔧 Compile & Run

```bash
g++ main_storage.cpp -o sbsa_store
./sbsa_store
```

This will create a file in:
```
storage/slot_2/layer_2/file_3.5.txt
```

## 📦 Structure

- `sbsa_storage.cpp` – Implements persistent write/read using slots
- `main_storage.cpp` – Demo program: write a file, read it back
- `storage/` – Auto-created during run

## 📄 Output

```
Read from SBSA slot: This is file content.
```

## 📜 License

MIT — created by Aaron Cattell
