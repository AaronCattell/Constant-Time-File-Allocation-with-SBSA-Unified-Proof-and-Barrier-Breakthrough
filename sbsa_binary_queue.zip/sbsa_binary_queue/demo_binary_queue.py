from sbsa_binary_queue import SBSABinaryQueue

queue = SBSABinaryQueue(['Low', 'High'])

# Enqueue tasks
queue.enqueue('High', 0, 2.5, {'task': 'log_event', 'value': 42})
queue.enqueue('Low', 1, 4.0, {'task': 'send_email', 'to': 'admin@example.com'})

# Read and process
task1 = queue.read('High', 0, 2.5)
task2 = queue.read('Low', 1, 4.0)

print("Read tasks:")
print(task1)
print(task2)
