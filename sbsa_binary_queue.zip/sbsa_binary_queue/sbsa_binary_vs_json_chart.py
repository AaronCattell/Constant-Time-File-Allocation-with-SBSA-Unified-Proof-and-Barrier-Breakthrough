import matplotlib.pyplot as plt

# Simulated benchmark data
task_counts = [10, 100, 500, 1000, 2000]
json_times = [0.2, 1.8, 9.0, 17.5, 34.2]      # JSON queue: write + read times (simulated)
binary_times = [0.1, 0.9, 4.3, 8.6, 16.5]     # Binary (pickle) queue: write + read times

# Plot the comparison chart
plt.figure(figsize=(10, 6))
plt.plot(task_counts, json_times, label='JSON Queue', marker='o', color='blue')
plt.plot(task_counts, binary_times, label='Binary Queue (Pickle)', marker='s', color='purple')

plt.xlabel('Number of Tasks')
plt.ylabel('Total Write+Read Time (seconds)')
plt.title('SBSA Binary Queue vs JSON Queue Performance')
plt.legend()
plt.grid(True)
plt.tight_layout()

# Show or save
plt.savefig("sbsa_binary_vs_json_queue.png")
plt.show()
