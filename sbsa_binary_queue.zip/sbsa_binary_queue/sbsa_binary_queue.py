import os
import pickle
from pathlib import Path

class SBSABinaryQueue:
    def __init__(self, size_classes, root='queue_bin'):
        self.slots = {cls: i for i, cls in enumerate(size_classes)}
        self.root = Path(root)

    def get_path(self, size_class, thickness, width):
        slot = self.slots[size_class]
        return self.root / f"slot_{slot}" / f"layer_{thickness}" / f"job_{width}.bin"

    def enqueue(self, size_class, thickness, width, payload: dict):
        path = self.get_path(size_class, thickness, width)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'wb') as f:
            pickle.dump(payload, f)

    def read(self, size_class, thickness, width):
        path = self.get_path(size_class, thickness, width)
        if not path.exists():
            raise FileNotFoundError(f"No job found at {path}")
        with open(path, 'rb') as f:
            return pickle.load(f)
