## ⚙️ SBSA Async Job Queue

This extends SBSA to support async task queuing using file-backed slots.

### 🧪 How to Run the Async Demo

1. Install Python 3.8+
2. Run:

```bash
python demo_async_worker.py
```

### 🔄 What It Does

- Enqueues tasks into `queue_storage/slot_x/layer_y/job_z.json`
- Runs an `asyncio` worker to load and process each job
- Deletes each job after it's handled

Perfect for local queues, prototypes, or persistent lightweight schedulers.
