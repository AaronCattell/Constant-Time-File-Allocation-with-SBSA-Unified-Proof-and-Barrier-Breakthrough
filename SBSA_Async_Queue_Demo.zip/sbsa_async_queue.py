import os
import json
import asyncio
from pathlib import Path

class SBSAAsyncQueue:
    def __init__(self, size_classes, root='queue_storage'):
        self.slots = {cls: i for i, cls in enumerate(size_classes)}
        self.root = Path(root)

    def get_path(self, size_class, thickness, width):
        slot = self.slots[size_class]
        return self.root / f"slot_{slot}" / f"layer_{thickness}" / f"job_{width}.json"

    async def enqueue(self, size_class, thickness, width, payload: dict):
        path = self.get_path(size_class, thickness, width)
        path.parent.mkdir(parents=True, exist_ok=True)
        async with asyncio.to_thread(open, path, 'w') as f:
            json.dump(payload, f)

    async def run_worker(self, process_fn, poll_interval=1.0):
        print("SBSA Worker started...")
        while True:
            for slot_dir in sorted(self.root.glob("slot_*")):
                for layer_dir in sorted(slot_dir.glob("layer_*")):
                    for job_file in sorted(layer_dir.glob("job_*.json")):
                        try:
                            async with asyncio.to_thread(open, job_file) as f:
                                data = json.load(f)
                            await process_fn(data)
                            job_file.unlink()
                        except Exception as e:
                            print(f"Error processing {job_file}: {e}")
            await asyncio.sleep(poll_interval)
