import asyncio
from sbsa_async_queue import SBSAAsyncQueue

async def sample_task_handler(task):
    print(f"Processing: {task['task']}")
    await asyncio.sleep(0.2)  # simulate work

async def main():
    queue = SBSAAsyncQueue(['Low', 'Medium', 'High'])
    await queue.enqueue('High', 0, 1.5, {'task': 'email_user'})
    await queue.enqueue('Low', 0, 2.0, {'task': 'generate_report'})
    await queue.run_worker(sample_task_handler)

if __name__ == "__main__":
    asyncio.run(main())
