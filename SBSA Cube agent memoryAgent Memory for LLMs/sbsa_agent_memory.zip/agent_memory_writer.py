import json
import time
from pathlib import Path

class SBSACubeWriter:
    def __init__(self, root="agent_memory"):
        self.root = Path(root)

    def write_memory(self, agent_id, step, memory_type, content):
        timestamp = int(time.time())
        x1, x2 = agent_id, agent_id
        y1, y2 = step, step
        z_index = {"observation": 0, "thought": 1, "intention": 2}.get(memory_type, 3)

        payload = {
            "agent": agent_id,
            "step": step,
            "type": memory_type,
            "content": content,
            "timestamp": timestamp
        }

        faces = {
            'z1': (x1, y1), 'z2': (x2, y2),
            'x1': (y1, z_index), 'x2': (y2, z_index + 1),
            'y1': (x1, z_index), 'y2': (x2, z_index + 1)
        }

        for axis, (a, b) in faces.items():
            path = self.root / f"{axis}/{a}_{b}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(payload, f)
