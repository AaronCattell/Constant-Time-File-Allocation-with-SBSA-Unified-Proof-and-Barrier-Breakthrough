import json
from pathlib import Path

class SBSACubeReader:
    def __init__(self, root="agent_memory"):
        self.root = Path(root)

    def read_by_type(self, memory_type):
        z_map = {"observation": "z1", "thought": "z2"}
        axis = z_map.get(memory_type)
        if not axis:
            return []
        base = self.root / axis
        return [json.load(open(f)) for f in base.rglob("*.json")]

    def read_by_agent(self, agent_id):
        base = self.root / "y1"
        results = []
        for f in base.rglob(f"{agent_id}_*.json"):
            try:
                results.append(json.load(open(f)))
            except:
                continue
        return results
