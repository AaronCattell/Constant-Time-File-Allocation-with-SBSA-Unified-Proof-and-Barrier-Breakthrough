# SBSA Agent Memory Cube

This folder contains a prototype agent memory system using SBSA Cube logic. Each memory is stored in 6 files, addressable by:

- Agent ID
- Step (time or turn)
- Memory Type (observation, thought, intention)

## Files

- `agent_memory_writer.py` — stores memories spatially
- `agent_memory_query.py` — retrieves by type or agent
- `example_agent_loop.py` — simulates agent memory flow

## Usage

```bash
python example_agent_loop.py
```

Then inspect the `agent_memory/` folder.
