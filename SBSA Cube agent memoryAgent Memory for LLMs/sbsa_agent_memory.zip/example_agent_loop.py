from agent_memory_writer import SBSACubeWriter
import time

cube = SBSACubeWriter()

cube.write_memory("agent_alpha", 1, "observation", "Saw a rock")
time.sleep(1)
cube.write_memory("agent_alpha", 2, "thought", "Should collect it")
time.sleep(1)
cube.write_memory("agent_alpha", 3, "intention", "Move toward the rock")
