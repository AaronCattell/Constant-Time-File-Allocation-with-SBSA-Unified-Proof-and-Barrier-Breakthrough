from sbsa_cube_reader import read_jobs_by_timestamp_range
import time

now = int(time.time())
start = now - 3600  # 1 hour ago
end = now

jobs = read_jobs_by_timestamp_range(start, end)

print("🕒 Recent Jobs:")
for job in jobs[:5]:
    print(f"[{job['status']}] Job {job['job_id']} at {job['timestamp']}")
