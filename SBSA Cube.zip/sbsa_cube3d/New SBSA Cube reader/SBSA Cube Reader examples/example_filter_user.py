from sbsa_cube_reader import read_jobs_by_status

running_jobs = read_jobs_by_status("running")
urgent_jobs = [job for job in running_jobs if job["user"] == "alice"]

print(f"🚀 Alice's running jobs: {len(urgent_jobs)}")
for job in urgent_jobs:
    print(f"Job {job['job_id']} at {job['timestamp']}")
