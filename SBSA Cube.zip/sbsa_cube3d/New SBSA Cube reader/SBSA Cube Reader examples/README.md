# SBSA Cube Reader Examples

These examples demonstrate how to use `sbsa_cube_reader.py` to fetch jobs stored using SBSA Cube logic.

## Included Scripts

- `example_read_queued.py`  
  Fetches jobs currently marked as `"queued"`

- `example_read_by_timestamp.py`  
  Gets jobs created within the last hour (or any time window)

- `example_filter_user.py`  
  Filters `"running"` jobs to only those submitted by a specific user

## Requirements

- `sbsa_cube_reader.py` must be in the same folder
- A valid SBSA Cube structure under `cube_jobs/`
- Python 3

## Run Instructions

```bash
python example_read_queued.py
