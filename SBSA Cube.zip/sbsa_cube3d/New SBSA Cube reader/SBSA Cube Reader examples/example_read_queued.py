from sbsa_cube_reader import read_jobs_by_status

queued_jobs = read_jobs_by_status("queued")

print("📦 Queued Jobs:")
for job in queued_jobs[:5]:
    print(f"Job {job['job_id']} by {job['user']} at {job['timestamp']}")
