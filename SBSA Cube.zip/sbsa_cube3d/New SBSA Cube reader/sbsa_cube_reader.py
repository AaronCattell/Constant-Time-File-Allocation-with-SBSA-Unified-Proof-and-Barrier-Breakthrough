import json
from pathlib import Path

# Status map must match what was used when writing
STATUS_MAP = {
    'queued': 'z1',
    'running': 'z2',
    'done': 'z3'  # Optional if you wrote using z2 for done
}

CUBE_ROOT = Path("cube_jobs")


def read_jobs_by_status(status):
    axis = STATUS_MAP.get(status)
    if not axis:
        raise ValueError(f"Unknown status: {status}")
    
    dir_path = CUBE_ROOT / axis
    jobs = []
    for file in dir_path.rglob("*.json"):
        try:
            with open(file) as f:
                job = json.load(f)
                jobs.append(job)
        except Exception as e:
            print(f"Error reading {file}: {e}")
    return jobs


def read_jobs_by_timestamp_range(start_ts, end_ts):
    axis = "z1"  # Or whatever status face you want to scan
    dir_path = CUBE_ROOT / axis
    jobs = []
    for file in dir_path.rglob("*.json"):
        try:
            with open(file) as f:
                job = json.load(f)
                ts = job.get("timestamp", 0)
                if start_ts <= ts <= end_ts:
                    jobs.append(job)
        except Exception as e:
            print(f"Error reading {file}: {e}")
    return jobs


# --- Example usage ---
if __name__ == "__main__":
    print("Jobs with status QUEUED:")
    queued = read_jobs_by_status("queued")
    for job in queued[:5]:
        print(job)

    print("\nJobs in time range:")
    from time import time
    now = int(time())
    recent_jobs = read_jobs_by_timestamp_range(now - 5000, now)
    for job in recent_jobs[:5]:
        print(job)
