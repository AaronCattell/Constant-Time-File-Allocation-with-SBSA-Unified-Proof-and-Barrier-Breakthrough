from sbsa_cube_writer import SBSACubeWriter
import time
import json

# AI Memory Cube — store LLM memories by (agent, time, memory_type)

# Setup
cube = SBSACubeWriter()
agent_id = 42
timestamp = int(time.time())

# Define memory categories
MEMORY_TYPES = {
    "plan": 0,
    "fact": 1,
    "dialog": 2
}

# Example memory payloads
memories = [
    {"type": "plan", "content": "Respond to user email"},
    {"type": "fact", "content": "User prefers night mode"},
    {"type": "dialog", "content": "Hi, how can I help you today?"}
]

# Write each memory to its logical cube cell
for mem in memories:
    z = MEMORY_TYPES[mem["type"]]
    cube.write_cube(
        x1=agent_id, x2=agent_id + 1,
        y1=timestamp, y2=timestamp + 1,
        z1=z, z2=z + 1,
        payload={"agent": agent_id, **mem}
    )

print("✅ AI memory cube written to sbsa_cube_storage/")
