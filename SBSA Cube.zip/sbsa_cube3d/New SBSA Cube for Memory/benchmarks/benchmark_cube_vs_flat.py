import time
import json
import matplotlib.pyplot as plt
from pathlib import Path

# --- SBSA Cube Writer ---
class SBSACubeWriter:
    def __init__(self, root='sbsa_cube_storage'):
        self.root = Path(root)

    def get_path(self, axis, coord1, coord2):
        return self.root / f"{axis}" / f"{coord1}_{coord2}.json"

    def write_cube(self, x1, x2, y1, y2, z1, z2, payload):
        faces = {
            'z1': (x1, y1), 'z2': (x2, y2),
            'x1': (y1, z1), 'x2': (y2, z2),
            'y1': (x1, z1), 'y2': (x2, z2),
        }
        for axis, (c1, c2) in faces.items():
            path = self.get_path(axis, c1, c2)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(payload, f)

# --- Flat List Writer ---
class FlatMemoryWriter:
    def __init__(self, file='flat_memory.json'):
        self.file = Path(file)
        self.memory = []

    def write_memory(self, payload):
        self.memory.append(payload)
        with open(self.file, 'w') as f:
            json.dump(self.memory, f)

# --- Benchmark ---
N = 200
agent_id = 7
timestamp_base = int(time.time())
memory_type = 0

cube = SBSACubeWriter()
flat = FlatMemoryWriter()

cube_times, flat_times = [], []

for i in range(N):
    ts = timestamp_base + i
    payload = {
        "agent": agent_id,
        "type": "plan",
        "content": f"Task {i}",
        "timestamp": ts
    }

    # SBSA Cube
    t0 = time.perf_counter()
    cube.write_cube(
        x1=agent_id, x2=agent_id + 1,
        y1=ts, y2=ts + 1,
        z1=memory_type, z2=memory_type + 1,
        payload=payload
    )
    cube_times.append(time.perf_counter() - t0)

    # Flat File
    t0 = time.perf_counter()
    flat.write_memory(payload)
    flat_times.append(time.perf_counter() - t0)

# --- Plotting ---
plt.figure(figsize=(10, 6))
plt.plot(cube_times, label="SBSA Cube", color="blue")
plt.plot(flat_times, label="Flat JSON Memory", color="gray")
plt.xlabel("Memory Index")
plt.ylabel("Write Time (seconds)")
plt.title("SBSA Cube vs Flat File Memory Benchmark")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("sbsa_vs_flat_memory_benchmark.png")
plt.show()
