import time
import json
import matplotlib.pyplot as plt
from pathlib import Path

# === SBSA Cube Writer ===
class SBSACubeWriter:
    def __init__(self, root='sbsa_cube_storage'):
        self.root = Path(root)

    def get_path(self, axis, coord1, coord2):
        return self.root / f"{axis}" / f"{coord1}_{coord2}.json"

    def write_cube(self, x1, x2, y1, y2, z1, z2, payload):
        faces = {
            'z1': (x1, y1), 'z2': (x2, y2),
            'x1': (y1, z1), 'x2': (y2, z2),
            'y1': (x1, z1), 'y2': (x2, z2),
        }
        for axis, (c1, c2) in faces.items():
            path = self.get_path(axis, c1, c2)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(payload, f)

# === Benchmark ===
cube = SBSACubeWriter()
N = 500
agent_id = 101
memory_type = 0  # e.g., 'plan'
timestamp_base = int(time.time())
write_times = []

for i in range(N):
    ts = timestamp_base + i
    payload = {
        "agent": agent_id,
        "type": "plan",
        "content": f"task {i}"
    }
    t0 = time.perf_counter()
    cube.write_cube(
        x1=agent_id, x2=agent_id + 1,
        y1=ts, y2=ts + 1,
        z1=memory_type, z2=memory_type + 1,
        payload=payload
    )
    write_times.append(time.perf_counter() - t0)

# === Plot ===
plt.figure(figsize=(10, 5))
plt.plot(write_times, label="SBSA Cube Write Time", color="blue")
plt.xlabel("Memory Index")
plt.ylabel("Write Time (seconds)")
plt.title("AI Memory Cube Write Benchmark")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("ai_memory_cube_benchmark.png")
plt.show()

# Print summary
print(f"Average write time: {sum(write_times)/len(write_times):.6f} seconds")
