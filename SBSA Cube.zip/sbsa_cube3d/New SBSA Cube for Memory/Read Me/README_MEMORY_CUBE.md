# 🧠 How to Build an AI Memory Cube with SBSA

This guide shows how to use the `SBSACubeWriter` to build a **memory system** for AI agents, where each piece of memory is written spatially across **three logical axes**:

- `X` → Agent ID  
- `Y` → Time (timestamp or step)  
- `Z` → Memory Type (Plan, Fact, Dialog, etc.)

## 📐 Concept

A memory cube is a 3D layout of memory entries, where one write stores to 6 mirrored positions for instant access by any axis.


         +------------+
        /            /|
       +------------+ |
      |  Memory     | |
      |   Cube      | +
      |             |/
      +-------------+

X = Agent | Y = Time | Z = Type


## ✅ Example Memory Types

```python
MEMORY_TYPES = {
    "plan": 0,
    "fact": 1,
    "dialog": 2
}

🚀 How to Use
1. Install dependencies
Just standard Python:

python ai_memory_cube.py

2. Write to the cube
Use sbsa_cube_writer.py:
----------------------------------------------------------------------------
from sbsa_cube_writer import SBSACubeWriter
import time

cube = SBSACubeWriter()
agent_id = 42
timestamp = int(time.time())

cube.write_cube(
    x1=agent_id,
    x2=agent_id + 1,
    y1=timestamp,
    y2=timestamp + 1,
    z1=0,  # Plan
    z2=1,
    payload={"type": "plan", "content": "Summarize meeting"}
)
-----------------------------------------------------------------------------------------
3. Read from cube
Read by any face:

with open("sbsa_cube_storage/z1/42_17185600.json") as f:
    data = json.load(f)


🧠 Why This Works
$\mathcal{O}(1)$ write and lookup time

Spatially grouped by agent, time, and type

Great for LLM agents, symbolic memory, and task scheduling

Created by Aaron Cattell · MIT License · Powered by SBSA
