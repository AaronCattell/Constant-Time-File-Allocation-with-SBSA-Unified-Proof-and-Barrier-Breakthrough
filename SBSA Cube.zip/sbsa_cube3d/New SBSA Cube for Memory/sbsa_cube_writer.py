import os
import json
from pathlib import Path

class SBSACubeWriter:
    def __init__(self, root='sbsa_cube_storage'):
        self.root = Path(root)

    def get_path(self, axis, coord1, coord2):
        return self.root / f"{axis}" / f"{coord1}_{coord2}.json"

    def write_cube(self, x1, x2, y1, y2, z1, z2, payload):
        faces = {
            'z1': (x1, y1),
            'z2': (x2, y2),
            'x1': (y1, z1),
            'x2': (y2, z2),
            'y1': (x1, z1),
            'y2': (x2, z2),
        }
        for axis, (coord1, coord2) in faces.items():
            path = self.get_path(axis, coord1, coord2)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(payload, f)
            print(f"Wrote to {path}")

# --- Demo ---
if __name__ == "__main__":
    cube = SBSACubeWriter()
    cube.write_cube(x1=1, x2=2, y1=3, y2=4, z1=5, z2=6, payload={"message": "cube write"})
