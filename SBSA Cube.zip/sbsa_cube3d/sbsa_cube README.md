# SBSA Cube

**SBSA Cube** is the core implementation of a spatial, constant-time memory system based on the Size-Based Slot Allocation (SBSA) model.

Each data point (task, memory, job) is written to six mirrored files across 3 dimensions — enabling O(1) access by any of its coordinates: ID, time, or type.

---

## 💡 Concept

Instead of appending to a single file or using tree/index-based lookups, SBSA Cube spreads each data entry across 6 file paths:

- `z1/` and `z2/` → Status slices
- `x1/` and `x2/` → Time slices
- `y1/` and `y2/` → ID slices

This creates a deterministic, addressable, and scalable memory structure.

---

## 📦 File Example

For task ID `17`, timestamp `1718623100`, and status `"doing"`:

```bash
cube_root/
├── z2/17_1718623100.json
├── x1/1718623100_1.json
├── y2/18_2.json
...

Each file contains the same JSON payload:

{
  "task_id": 17,
  "user": "bob",
  "status": "doing",
  "timestamp": 1718623100,
  "content": "Refactor the auth system"
}

🔧 Key Functions
write_cube(x1, x2, y1, y2, z1, z2, payload)
Writes the payload to 6 mirrored coordinates.

from sbsa_cube_writer import SBSACubeWriter

cube = SBSACubeWriter("cube_tasks")
cube.write_cube(1, 2, 100, 101, 0, 1, payload)

get_by_status(status_code)
Read back all files from one face (e.g., "doing" = z2/).

🧠 Why It Matters
✅ Constant-time access

✅ Structured like memory cubes, not arrays

✅ Easy to debug (files are visible)

✅ Great for AI agents, job schedulers, task graphs


🧪 Used In
sbsa_task_manager/ – Task queues with TODO → DONE flow

sbsa_quantum_queue/ – Qiskit job queueing

ai_memory_cube.py – LLM-accessible memory banks


🧩 License & Author
Created by Aaron Cattell
License: MIT
Backed by OpenAI's ChatGPT

“Memory doesn’t have to be fast when you know exactly where it is.”
— SBSA Design Principle

