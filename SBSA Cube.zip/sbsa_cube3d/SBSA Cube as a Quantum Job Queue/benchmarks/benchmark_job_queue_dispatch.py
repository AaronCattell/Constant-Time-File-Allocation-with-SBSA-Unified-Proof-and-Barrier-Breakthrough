import time
import json
import matplotlib.pyplot as plt
from pathlib import Path

# --- SBSA Cube Writer ---
class SBSACubeWriter:
    def __init__(self, root='cube_jobs'):
        self.root = Path(root)

    def get_path(self, axis, coord1, coord2):
        return self.root / f"{axis}" / f"{coord1}_{coord2}.json"

    def write_cube(self, x1, x2, y1, y2, z1, z2, payload):
        faces = {
            'z1': (x1, y1), 'z2': (x2, y2),
            'x1': (y1, z1), 'x2': (y2, z2),
            'y1': (x1, z1), 'y2': (x2, z2),
        }
        for axis, (c1, c2) in faces.items():
            path = self.get_path(axis, c1, c2)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(payload, f)

# --- Flat Queue Writer ---
class FlatQueue:
    def __init__(self, file='flat_jobs.json'):
        self.file = Path(file)
        self.jobs = []

    def write_job(self, payload):
        self.jobs.append(payload)
        with open(self.file, 'w') as f:
            json.dump(self.jobs, f)

    def get_jobs_by_status(self, status):
        return [j for j in self.jobs if j['status'] == status]

# --- Benchmark ---
N = 300
timestamp = int(time.time())
job_status = 'queued'

cube = SBSACubeWriter()
flat = FlatQueue()

cube_times, flat_times = [], []

# Dispatch jobs
for i in range(N):
    job = {
        'job_id': i,
        'user': 'q_user',
        'status': job_status,
        'timestamp': timestamp + i
    }

    t0 = time.perf_counter()
    cube.write_cube(i, i+1, timestamp+i, timestamp+i+1, 0, 1, job)
    cube_times.append(time.perf_counter() - t0)

    t0 = time.perf_counter()
    flat.write_job(job)
    flat_times.append(time.perf_counter() - t0)

# Query phase
t0 = time.perf_counter()
cube_query_path = Path("cube_jobs/z1")
cube_files = list(cube_query_path.rglob("*.json"))
cube_results = [json.load(open(f)) for f in cube_files]
cube_query_time = time.perf_counter() - t0

t0 = time.perf_counter()
flat_results = flat.get_jobs_by_status("queued")
flat_query_time = time.perf_counter() - t0

# --- Plot ---
plt.figure(figsize=(10, 6))
plt.plot(cube_times, label='SBSA Cube Write', color='blue')
plt.plot(flat_times, label='Flat Queue Write', color='gray')
plt.xlabel("Job Index")
plt.ylabel("Write Time (seconds)")
plt.title("Job Dispatch Benchmark: SBSA Cube vs Flat JSON")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("job_dispatch_benchmark.png")
plt.show()

print(f"📦 Cube query time: {cube_query_time:.6f} s")
print(f"📄 Flat query time: {flat_query_time:.6f} s")
