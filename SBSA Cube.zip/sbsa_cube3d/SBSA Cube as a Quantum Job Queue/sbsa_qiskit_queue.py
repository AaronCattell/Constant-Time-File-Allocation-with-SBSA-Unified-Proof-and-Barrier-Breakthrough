from sbsa_cube_writer import SBSACubeWriter
from qiskit import QuantumCircuit, transpile, Aer, execute
import time
import json

# --- Setup ---
cube = SBSACubeWriter()
timestamp = int(time.time())
job_status_map = {'queued': 0, 'running': 1, 'done': 2}

# --- Simulate a user submitting a quantum job ---
def submit_job(circuit_id, user_id, job_status='queued'):
    qc = QuantumCircuit(2)
    qc.h(0)
    qc.cx(0, 1)

    payload = {
        'circuit_id': circuit_id,
        'user_id': user_id,
        'status': job_status,
        'timestamp': timestamp,
        'qasm': qc.qasm()
    }

    status_code = job_status_map[job_status]
    cube.write_cube(
        x1=circuit_id, x2=circuit_id + 1,
        y1=timestamp, y2=timestamp + 1,
        z1=status_code, z2=status_code + 1,
        payload=payload
    )
    print(f"✅ Job submitted for circuit {circuit_id} (status: {job_status})")

# --- Submit 3 example jobs ---
submit_job(circuit_id=10, user_id='alice')
submit_job(circuit_id=11, user_id='bob', job_status='running')
submit_job(circuit_id=12, user_id='charlie', job_status='done')
