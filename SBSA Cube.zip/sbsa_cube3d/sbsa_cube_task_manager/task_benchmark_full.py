import time
import json
import matplotlib.pyplot as plt
from pathlib import Path

# --- SBSA Task Writer ---
class SBSATaskWriter:
    def __init__(self, root="cube_tasks"):
        self.root = Path(root)

    def write_cube(self, x1, x2, y1, y2, z1, z2, payload):
        faces = {
            'z1': (x1, y1), 'z2': (x2, y2),
            'x1': (y1, z1), 'x2': (y2, z2),
            'y1': (x1, z1), 'y2': (x2, z2),
        }
        for axis, (c1, c2) in faces.items():
            path = self.root / f"{axis}/{c1}_{c2}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(payload, f)

# --- Flat List Task Manager ---
class FlatTaskManager:
    def __init__(self, file='flat_jobs.json'):
        self.file = Path(file)
        self.tasks = []

    def add_task(self, task_id, user, status, content):
        task = {
            "task_id": task_id,
            "user": user,
            "status": status,
            "timestamp": int(time.time()),
            "content": content
        }
        self.tasks.append(task)
        with open(self.file, 'w') as f:
            json.dump(self.tasks, f)

    def get_by_status(self, status):
        return [t for t in self.tasks if t["status"] == status]

# --- SBSA Reader ---
class SBSACubeReader:
    def __init__(self, root='cube_tasks'):
        self.root = Path(root)

    def get_by_status(self, status_code):
        dir_path = self.root / f"z{status_code + 1}"
        jobs = []
        for file in dir_path.rglob("*.json"):
            try:
                with open(file) as f:
                    jobs.append(json.load(f))
            except:
                pass
        return jobs

# --- Benchmark Setup ---
N = 300
statuses = ["todo", "doing", "done"]

flat = FlatTaskManager()
sbsa = SBSATaskWriter()

flat_write_times = []
sbsa_write_times = []

# --- Write Benchmark ---
for i in range(N):
    status = statuses[i % 3]
    payload = {
        "task_id": i,
        "user": "agent",
        "status": status,
        "timestamp": int(time.time()),
        "content": f"Task {i}"
    }

    # SBSA write
    t0 = time.perf_counter()
    sbsa.write_cube(i, i+1, i+1000, i+1001, statuses.index(status), statuses.index(status)+1, payload)
    sbsa_write_times.append(time.perf_counter() - t0)

    # Flat write
    t0 = time.perf_counter()
    flat.add_task(i, "agent", status, f"Task {i}")
    flat_write_times.append(time.perf_counter() - t0)

# --- Read Benchmark ---
flat_reader = FlatTaskManager("flat_jobs.json")
sbsa_reader = SBSACubeReader("cube_tasks")

# Read 'doing' tasks
t0 = time.perf_counter()
flat_results = flat_reader.get_by_status("doing")
flat_read_time = time.perf_counter() - t0

t0 = time.perf_counter()
sbsa_results = sbsa_reader.get_by_status(1)
sbsa_read_time = time.perf_counter() - t0

# --- Chart Write Performance ---
plt.figure(figsize=(10, 6))
plt.plot(sbsa_write_times, label="SBSA Cube Write", color="blue")
plt.plot(flat_write_times, label="Flat List Write", color="gray")
plt.xlabel("Task Index")
plt.ylabel("Write Time (sec)")
plt.title("Write Time: SBSA Cube vs Flat Task Manager")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("task_write_benchmark_chart.png")
plt.show()

# --- Chart Read Performance ---
flat_read_time = max(flat_read_time, 0.000001)
sbsa_read_time = max(sbsa_read_time, 0.000001)

plt.figure()
plt.bar(["Flat JSON", "SBSA Cube"], [flat_read_time, sbsa_read_time], color=["gray", "blue"])
plt.ylabel("Read Time (sec)")
plt.title("Read Time for 'doing' Tasks")
plt.tight_layout()
plt.savefig("task_read_benchmark_chart.png")
plt.show()

# --- Console Summary ---
print(f"Flat JSON Read Time: {flat_read_time:.6f} s ({len(flat_results)} tasks)")
print(f"SBSA Cube Read Time: {sbsa_read_time:.6f} s ({len(sbsa_results)} tasks)")
