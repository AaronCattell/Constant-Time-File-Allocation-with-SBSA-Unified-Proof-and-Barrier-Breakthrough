# SBSA Cube Task Manager Example

This demonstrates a task manager using SBSA Cube logic. Each task is stored in 6 files for constant-time retrieval by:

- `x`: task ID
- `y`: timestamp
- `z`: task status

## Files

- `task_manager.py` — handles task writes
- `example_task_flow.py` — simulates a task moving from TODO to DONE

## Usage

Make sure `sbsa_cube_writer.py` is in the same folder. Then run:

```
python example_task_flow.py
```

Check the `sbsa_tasks/` folder to see the task cube in action.
