from task_manager import TaskManager
import time

tm = TaskManager()

# Create tasks
tm.add_task(1, "alice", "todo", "Fix login bug")
time.sleep(1)
tm.add_task(1, "alice", "doing", "Fix login bug")
time.sleep(1)
tm.add_task(1, "alice", "done", "Fix login bug")

tm.add_task(2, "bob", "todo", "Add logout endpoint")
time.sleep(1)
tm.add_task(2, "bob", "doing", "Add logout endpoint")
time.sleep(1)
tm.add_task(2, "bob", "done", "Add logout endpoint")
