from sbsa_cube_writer import SBSACubeWriter
import time

class TaskManager:
    def __init__(self, root="sbsa_tasks"):
        self.cube = SBSACubeWriter(root=root)
        self.status_map = {"todo": 0, "doing": 1, "done": 2}

    def add_task(self, task_id, user, status, content):
        timestamp = int(time.time())
        z = self.status_map.get(status, 0)

        self.cube.write_cube(
            x1=task_id, x2=task_id + 1,
            y1=timestamp, y2=timestamp + 1,
            z1=z, z2=z + 1,
            payload={
                "task_id": task_id,
                "user": user,
                "status": status,
                "timestamp": timestamp,
                "content": content
            }
        )
