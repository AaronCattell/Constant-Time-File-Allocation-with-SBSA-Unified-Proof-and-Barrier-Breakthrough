import time
import json
import matplotlib.pyplot as plt
from pathlib import Path

# --- SBSA Task Manager ---
class SBSAStubWriter:
    def __init__(self, root="cube_tasks"):
        self.root = Path(root)

    def write_cube(self, x1, x2, y1, y2, z1, z2, payload):
        faces = {
            'z1': (x1, y1), 'z2': (x2, y2),
            'x1': (y1, z1), 'x2': (y2, z2),
            'y1': (x1, z1), 'y2': (x2, z2),
        }
        for axis, (c1, c2) in faces.items():
            path = self.root / f"{axis}/{c1}_{c2}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(payload, f)

# --- Flat List Task Manager ---
class FlatTaskManager:
    def __init__(self):
        self.tasks = []

    def add_task(self, task_id, user, status, content):
        self.tasks.append({
            "task_id": task_id,
            "user": user,
            "status": status,
            "timestamp": int(time.time()),
            "content": content
        })

# --- Benchmark ---
N = 300
statuses = ["todo", "doing", "done"]

sbsa = SBSAStubWriter()
flat = FlatTaskManager()

sbsa_times = []
flat_times = []

for i in range(N):
    status = statuses[i % 3]
    payload = {
        "task_id": i,
        "user": "user_1",
        "status": status,
        "timestamp": int(time.time()),
        "content": f"Task #{i}"
    }

    # SBSA
    t0 = time.perf_counter()
    sbsa.write_cube(i, i + 1, i + 100, i + 101, statuses.index(status), statuses.index(status) + 1, payload)
    sbsa_times.append(time.perf_counter() - t0)

    # Flat
    t0 = time.perf_counter()
    flat.add_task(i, "user_1", status, f"Task #{i}")
    flat_times.append(time.perf_counter() - t0)

# --- Plot ---
plt.figure(figsize=(10, 6))
plt.plot(sbsa_times, label="SBSA Cube Task Write", color="blue")
plt.plot(flat_times, label="Flat List Task Write", color="gray")
plt.xlabel("Task Index")
plt.ylabel("Write Time (seconds)")
plt.title("SBSA Cube vs Flat List Task Manager Benchmark")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("/mnt/data/sbsa_task_benchmark_chart.png")
plt.show()
