from sbsa_cube_writer import SBSACubeWriter

cube = SBSACubeWriter()
cube.write_cube(
    x1=0, x2=1,
    y1=0, y2=1,
    z1=0, z2=1,
    payload={"id": "cube_001", "type": "event", "value": 42}
)
