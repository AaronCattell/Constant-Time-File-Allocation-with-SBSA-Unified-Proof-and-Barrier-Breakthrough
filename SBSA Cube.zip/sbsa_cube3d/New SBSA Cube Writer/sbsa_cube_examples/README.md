# SBSA Cube Writer Examples

This folder contains usage examples for the `sbsa_cube_writer.py` system.

## Files

- `example_1_minimal_write.py` — Basic cube write
- `example_2_task_shard.py` — Simulates task queue sharding
- `example_3_agent_memory.py` — Logs memory with time and agent ID

## How to Use

Place `sbsa_cube_writer.py` in the same directory and run:
```bash
python example_1_minimal_write.py
```

Explore the `sbsa_cube_storage/` output folder.
