from sbsa_cube_writer import SBSACubeWriter
import time

cube = SBSACubeWriter()
agent_id = 7
timestamp = int(time.time())

cube.write_cube(
    x1=agent_id,
    x2=agent_id + 1,
    y1=timestamp,
    y2=timestamp + 10,
    z1=0,
    z2=1,
    payload={"agent": "alpha", "memory": "user asked for help", "importance": 0.9}
)
