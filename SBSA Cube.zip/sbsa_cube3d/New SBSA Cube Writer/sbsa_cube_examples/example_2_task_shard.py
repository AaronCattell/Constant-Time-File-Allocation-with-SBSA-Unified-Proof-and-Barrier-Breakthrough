from sbsa_cube_writer import SBSACubeWriter

cube = SBSACubeWriter()
for task_id in range(5):
    cube.write_cube(
        x1=task_id, x2=task_id + 1,
        y1=100 + task_id, y2=101 + task_id,
        z1=200 + task_id, z2=201 + task_id,
        payload={"task_id": task_id, "status": "queued", "priority": "high"}
    )
