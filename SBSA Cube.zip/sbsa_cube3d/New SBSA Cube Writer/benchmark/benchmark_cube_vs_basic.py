import time
import json
import matplotlib.pyplot as plt
from pathlib import Path

# SBSA Basic: 1 write per operation
class SBSAStorage:
    def __init__(self, root="sbsa_basic_benchmark"):
        self.root = Path(root)

    def write(self, slot, layer, width, payload):
        path = self.root / f"slot_{slot}" / f"layer_{layer}" / f"file_{width}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(payload, f)

# SBSA Cube Writer: 6 writes per operation
class SBSACubeWriter:
    def __init__(self, root='sbsa_cube_benchmark'):
        self.root = Path(root)

    def get_path(self, axis, coord1, coord2):
        return self.root / f"{axis}" / f"{coord1}_{coord2}.json"

    def write_cube(self, x1, x2, y1, y2, z1, z2, payload):
        faces = {
            'z1': (x1, y1),
            'z2': (x2, y2),
            'x1': (y1, z1),
            'x2': (y2, z2),
            'y1': (x1, z1),
            'y2': (x2, z2),
        }
        for axis, (coord1, coord2) in faces.items():
            path = self.get_path(axis, coord1, coord2)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f:
                json.dump(payload, f)

# Benchmarking
task_counts = list(range(100, 1100, 200))
sbsa_times, cube_times = [], []

for count in task_counts:
    sbsa = SBSAStorage()
    cube = SBSACubeWriter()
    payload = {"task": "benchmark", "value": 1}

    # SBSA basic
    start = time.perf_counter()
    for i in range(count):
        sbsa.write(slot=0, layer=0, width=i, payload=payload)
    sbsa_times.append(time.perf_counter() - start)

    # SBSA cube
    start = time.perf_counter()
    for i in range(count):
        cube.write_cube(i, i+1, i+2, i+3, i+4, i+5, payload)
    cube_times.append(time.perf_counter() - start)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(task_counts, sbsa_times, label="SBSA Basic", marker='o', color="green")
plt.plot(task_counts, cube_times, label="SBSA Cube Writer", marker='s', color="blue")
plt.xlabel("Number of Writes")
plt.ylabel("Total Time (seconds)")
plt.title("Benchmark: SBSA vs SBSA Cube Writer")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("sbsa_vs_cube_benchmark.png")
plt.show()
