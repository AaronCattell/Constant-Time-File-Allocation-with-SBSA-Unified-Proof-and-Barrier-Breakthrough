# 🧊 SBSA Cube Writer – 3D Spatial Logic

The `SBSACubeWriter` class extends the SBSA model into **three-dimensional space** by writing each data unit to **six logical faces** of a virtual cube.

---

## 🧠 Motivation

Traditional SBSA maps one logical path per operation:

/slot_x/layer_y/file_z.json


This is already constant-time, but *linear*.

The SBSA Cube Writer maps each operation into **6 files** across 3 axes:
- `z1` and `z2` — top and bottom
- `x1` and `x2` — left and right
- `y1` and `y2` — front and back

Each file becomes a projection of the same logical data point in different dimensions.

---

## 📂 Storage Layout

Example call:
```python
cube.write_cube(x1=1, x2=2, y1=3, y2=4, z1=5, z2=6, payload={...})

Creates:

sbsa_cube_storage/
├── z1/1_3.json
├── z2/2_4.json
├── x1/3_5.json
├── x2/4_6.json
├── y1/1_5.json
├── y2/2_6.json

📈 Benchmark

✅ SBSA Basic = 1 write per op

🔷 SBSA Cube = 6 writes per op

🧠 Both remain constant-time per write

🧊 Cube enables spatial grouping of memory, logs, or symbolic objects

🛠 Use Cases
LLM agent memory blocks

3D planning structures

Task scheduling across threads and time

AI environments using spatial rules

🚀 Try It
Run:

python sbsa_cube_writer.py

Explore:

sbsa_cube_storage/

Created by Aaron Cattell
Idea, code, and vision supported by AI tooling (ChatGPT)




