from qiskit import Aer, transpile, assemble
from sbsa_quantum_queue import SBSAQuantumQueue

size_classes = ['Low', 'Medium', 'High']
sbsa = SBSAQuantumQueue(size_classes)

# Create and store circuits
from qiskit import QuantumCircuit

circuits = []
for i in range(3):
    qc = QuantumCircuit(2, 2)
    qc.h(0)
    qc.cx(0, 1)
    qc.measure_all()
    circuits.append((qc, 'High', 0, i + 1.0))
    sbsa.write_circuit('High', 0, i + 1.0, qc)

# Load and run each
simulator = Aer.get_backend('qasm_simulator')

for (_, size_class, layer, width) in circuits:
    circuit = sbsa.read_circuit(size_class, layer, width)
    tqc = transpile(circuit, simulator)
    qobj = assemble(tqc)
    result = simulator.run(qobj).result()
    print(f"Results for width={width}: {result.get_counts()}")
