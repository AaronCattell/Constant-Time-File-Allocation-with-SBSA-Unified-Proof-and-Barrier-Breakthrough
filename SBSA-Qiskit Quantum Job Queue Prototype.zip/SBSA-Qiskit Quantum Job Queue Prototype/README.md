# 🧠 SBSA-Qiskit Quantum Job Queue (Prototype)

This project demonstrates how to use **SBSA (Size-Based Slot Allocation)** as a logical scheduler for Qiskit quantum circuits.

Instead of using comparison-based queues or databases, circuits are classified into `(slot, thickness, width)` for constant-time access.

---

## 🧪 What It Does

- Stores circuits using:

storage/slot_{priority}/layer_{queue}/file_{width}.qasm

- Loads them later for execution
- Outputs results from Qiskit simulator

---

## 📦 Files

| File                  | Purpose                                |
|-----------------------|----------------------------------------|
| `sbsa_quantum_queue.py` | SBSA-based circuit save/load logic    |
| `demo_qiskit_queue.py`  | Generates and runs Qiskit circuits    |
| `storage/`              | Auto-created directory tree           |

---

## ▶️ How to Run

Install requirements:
```bash
pip install qiskit

Run the demo:
python demo_qiskit_queue.py

Example output:
Results for width=1.0: {'00': 506, '11': 518}
Results for width=2.0: {'00': 499, '11': 525}
...

🧠 Why SBSA?
Most schedulers use:

Priority queues (O(log n))

Relational storage

Timestamp-based sort

SBSA replaces that with deterministic slotting:

(priority, queue, time) → location

🔬 Use Cases
Hybrid quantum/classical job routing

Persistent quantum workflows

Real-time circuit archiving or streaming


📜 License
MIT — created by Aaron Cattell
Assisted by ChatGPT

GitHub: aaroncattell/sbsa


---

## 📄 LICENSE (MIT)

```text
MIT License

Copyright (c) 2024 Aaron Cattell

Permission is hereby granted, free of charge, to any person obtaining a copy...
