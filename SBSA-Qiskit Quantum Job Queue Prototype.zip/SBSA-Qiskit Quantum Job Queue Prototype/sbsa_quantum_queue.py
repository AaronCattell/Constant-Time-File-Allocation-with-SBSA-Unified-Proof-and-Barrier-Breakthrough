import os
from qiskit import QuantumCircuit

class SBSAQuantumQueue:
    def __init__(self, size_classes):
        self.slots = {cls: i for i, cls in enumerate(size_classes)}

    def get_path(self, size_class, thickness, width):
        if size_class not in self.slots:
            raise ValueError(f"Invalid size class: {size_class}")
        slot = self.slots[size_class]
        return f"storage/slot_{slot}/layer_{thickness}/file_{width}.qasm"

    def write_circuit(self, size_class, thickness, width, circuit: QuantumCircuit):
        path = self.get_path(size_class, thickness, width)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            f.write(circuit.qasm())

    def read_circuit(self, size_class, thickness, width):
        from qiskit import QuantumCircuit
        path = self.get_path(size_class, thickness, width)
        if not os.path.exists(path):
            raise FileNotFoundError(f"No such circuit: {path}")
        return QuantumCircuit.from_qasm_file(path)
