# sbsa_memory_api.py

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sbsa_llm_memory_manager import SBSAHypercube

app = FastAPI()
mem = SBSAHypercube()

class MemoryStoreRequest(BaseModel):
    size_class: str
    thickness: float
    width: float
    version: int
    content: str

class MemoryRetrieveRequest(BaseModel):
    size_class: str
    thickness: float
    width: float
    version: int

@app.get("/")
def root():
    return {"message": "SBSA Hypercube Memory API is running."}

@app.post("/store")
def store_memory(req: MemoryStoreRequest):
    try:
        mem.store_memory(
            size_class=req.size_class,
            thickness=req.thickness,
            width=req.width,
            version=req.version,
            content=req.content
        )
        return {"status": "stored", "key": [req.size_class, req.thickness, req.width, req.version]}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/retrieve")
def retrieve_memory(req: MemoryRetrieveRequest):
    try:
        result = mem.retrieve_memory(
            size_class=req.size_class,
            thickness=req.thickness,
            width=req.width,
            version=req.version
        )
        return {"result": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
