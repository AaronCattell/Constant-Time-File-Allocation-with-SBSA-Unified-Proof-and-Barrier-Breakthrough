# agent_memory_example.py

from sbsa_llm_memory_manager import SBSAHypercube
import random

agent_memory = SBSAHypercube()

def simulate_agent_thinking(agent_id="A", version=0):
    for i in range(5):
        obs = f"{agent_id} observed: object-{i}"
        action = f"{agent_id} acted on: object-{i}"
        width = round(random.uniform(1.0, 3.0), 2)
        thickness = 5 + i * 2
        size_class = "2KB" if i % 2 == 0 else "4KB"

        agent_memory.store_memory(size_class, thickness, width, version, obs)
        agent_memory.store_memory(size_class, thickness + 1, width, version, action)
        print(f"[{i}] Stored memory @ ({size_class}, {thickness}, {width}, {version})")

def reflect_on_past(size_class, version):
    print(f"\nReflecting on version {version}:")
    for t in range(5, 15, 2):
        w = round(1.0 + (t % 3) * 0.5, 2)
        result = agent_memory.retrieve_memory(size_class, t, w, version)
        print(f"  Memory @ t={t}, w={w}: {result}")

simulate_agent_thinking(version=1)
simulate_agent_thinking(version=2)

reflect_on_past("2KB", 1)
reflect_on_past("2KB", 2)
