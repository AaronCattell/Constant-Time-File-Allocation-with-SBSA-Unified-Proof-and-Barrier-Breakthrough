# sbsa_memory_client.py

import requests

BASE_URL = "http://127.0.0.1:8000"

# Store memory
store_payload = {
    "size_class": "2KB",
    "thickness": 10.5,
    "width": 1.25,
    "version": 1,
    "content": "Agent observed red ball in simulation A."
}

response = requests.post(f"{BASE_URL}/store", json=store_payload)
print("[STORE]", response.status_code, response.json())

# Retrieve memory
retrieve_payload = {
    "size_class": "2KB",
    "thickness": 10.5,
    "width": 1.25,
    "version": 1
}

response = requests.post(f"{BASE_URL}/retrieve", json=retrieve_payload)
print("[RETRIEVE]", response.status_code, response.json())
