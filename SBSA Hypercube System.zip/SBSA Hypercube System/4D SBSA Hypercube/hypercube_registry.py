class HypercubeRegistry:
    def __init__(self):
        self.index = {}

    def register(self, size_class, thickness, width, version, cube_path):
        key = map_hypercube(size_class, thickness, width, version)
        self.index[key] = cube_path

    def lookup(self, size_class, thickness, width, version):
        return self.index.get(map_hypercube(size_class, thickness, width, version), None)
