

# 🧠 SBSA Hypercube

This project extends the original SBSA Cube model into a 4D spatial addressing system, forming a recursive, scalable structure ideal for structured memory, AI agents, logic systems, and versioned data layers.

## 🧩 Concept

Each SBSA Cube is indexed using 4 spatial dimensions:

- **X (slot)** — Size class: `'1KB'`, `'2KB'`, `'4KB'`, `'8KB'`
- **Y (thickness)** — Priority, depth, or complexity layer
- **Z (width)** — Memory span or width in logical space
- **W (version)** — Version, time slice, or agent-specific logic

The entire system supports constant-time lookup and highly structured parallel access.

---

## 📂 Files

| File                      | Purpose                                                |
|---------------------------|--------------------------------------------------------|
| `sbsa_hypercube_core.py`  | Core logic: quantization and 4D coordinate mapping     |
| `hypercube_registry.py`   | Index and retrieve SBSA Cubes by 4D key                |
| `example_usage.py`        | Demonstrates how to register and look up a cube path   |

---

## ✅ Example

```python
from hypercube_registry import HypercubeRegistry

registry = HypercubeRegistry()

# Register cubes
registry.register("2KB", thickness=6.2, width=1.03, version=0, cube_path="cube_alpha/")
registry.register("4KB", thickness=14.9, width=2.498, version=1, cube_path="cube_beta/")

# Lookup
print(registry.lookup("2KB", 6.2, 1.03, 0))  # → cube_alpha/
print(registry.lookup("4KB", 14.9, 2.498, 1))  # → cube_beta/
🧠 Use Cases
Versioned memory for agents and simulations

Parallel SBSA logic systems

Structured quantum task queues

Hierarchical memory for LLMs and symbolic planners

📦 How It Works
Each SBSA Cube is mapped to a 4D coordinate:

python

(slot, thickness, width, version)
Using simple quantization and indexing logic, this hypercube system allows:

Direct spatial memory management

Recursion and multi-layer storage

Constant-time dispatch across 4D memory space

Designed to scale where B-trees, flat logs, and hash tables collapse.