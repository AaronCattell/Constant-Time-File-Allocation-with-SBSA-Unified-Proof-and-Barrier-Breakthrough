cube1 = map_hypercube("2KB", thickness=6.2, width=1.03, version=0)  # → (1, 5, 1.05, 0)
cube2 = map_hypercube("4KB", thickness=14.9, width=2.498, version=1)  # → (2, 15, 2.5, 1)
