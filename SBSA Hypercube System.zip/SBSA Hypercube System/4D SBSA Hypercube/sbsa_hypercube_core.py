# === SBSA Hypercube Core ===

# Define the base size classes
size_classes = ['1KB', '2KB', '4KB', '8KB']
slots = {s: i for i, s in enumerate(size_classes)}

# Quantization parameters
MIN_WIDTH = 0.01
MAX_WIDTH = 1e6
QUANTUM = 0.05

MIN_THICKNESS = 0
MAX_THICKNESS = 1e6
THICKNESS_QUANTUM = 5

MAX_VERSION = 1e4  # Limit versions if needed

def quantize(value, quantum):
    """Round value to the nearest multiple of quantum."""
    return round(value / quantum) * quantum

def map_hypercube(size_class, thickness, width, version):
    """
    Maps a cube into a 4D coordinate: (slot, thickness, width, version)
    Used to group SBSA cubes into a hypercube model.
    """
    # Validate size class
    slot = slots.get(size_class)
    if slot is None:
        raise ValueError(f"Invalid size class: {size_class}")

    # Validate and quantize width
    if not isinstance(width, (int, float)) or width != width or width == float('inf'):
        raise ValueError("Width must be a finite, real number")
    width = quantize(width, QUANTUM)
    if not (MIN_WIDTH <= width <= MAX_WIDTH):
        raise ValueError(f"Width {width} out of bounds")

    # Validate and quantize thickness
    if not isinstance(thickness, (int, float)) or thickness != thickness or thickness == float('inf'):
        raise ValueError("Thickness must be a finite, real number")
    thickness = int(quantize(thickness, THICKNESS_QUANTUM))
    if not (MIN_THICKNESS <= thickness <= MAX_THICKNESS):
        raise ValueError(f"Thickness {thickness} out of bounds")

    # Version layer (4D)
    if not isinstance(version, int) or not (0 <= version <= MAX_VERSION):
        raise ValueError("Invalid version index")

    return (slot, thickness, width, version)
