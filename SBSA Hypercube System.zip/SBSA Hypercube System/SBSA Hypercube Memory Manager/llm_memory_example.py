from sbsa_llm_memory_manager import SBSAHypercube

# Step 1: Initialize the memory manager
manager = SBSAHypercube()

# Step 2: Store memory blocks
manager.store_memory(
    size_class="2KB",
    thickness=10.5,        # Memory depth
    width=1.25,            # Task width or context span
    version=0,             # Agent version or session
    content="Agent A observed: Room contains a table."
)

manager.store_memory(
    size_class="4KB",
    thickness=20.0,
    width=2.75,
    version=1,
    content="Agent A updated belief: Table has books."
)

# Step 3: Retrieve memory
result1 = manager.retrieve_memory("2KB", 10.5, 1.25, 0)
print("[Retrieval 1]", result1)

result2 = manager.retrieve_memory("4KB", 20.0, 2.75, 1)
print("[Retrieval 2]", result2)

# Step 4: Try retrieving non-existent memory
missing = manager.retrieve_memory("1KB", 5.0, 0.5, 0)
print("[Missing Block]", missing)
