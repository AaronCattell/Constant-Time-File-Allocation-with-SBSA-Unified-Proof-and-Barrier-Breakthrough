import time
import matplotlib.pyplot as plt

# --- SBSA Hypercube Mock using dict ---
class SBSAHypercubeMock:
    def __init__(self):
        self.data = {}

    def store(self, key, value):
        self.data[key] = value

    def retrieve(self, key):
        return self.data.get(key, None)

# --- Flat Log Memory using list ---
class FlatLogMemory:
    def __init__(self):
        self.data = []

    def store(self, key, value):
        self.data.append((key, value))

    def retrieve(self, key):
        for k, v in self.data:
            if k == key:
                return v
        return None

# --- Benchmark Function ---
def benchmark(manager, N=1000):
    keys = [(f"A{i%4}", i % 30, round(i % 10 * 0.1, 2), i % 5) for i in range(N)]
    values = [f"Memory_{i}" for i in range(N)]

    # Store phase
    for i in range(N):
        manager.store(keys[i], values[i])

    # Retrieve phase
    start = time.time()
    for i in range(N):
        manager.retrieve(keys[i])
    end = time.time()

    return end - start

# --- Run Benchmark ---
sizes = [100, 500, 1000, 5000, 10000]
sbsa_times = []
flatlog_times = []

for N in sizes:
    sbsa = SBSAHypercubeMock()
    flat = FlatLogMemory()
    sbsa_times.append(benchmark(sbsa, N))
    flatlog_times.append(benchmark(flat, N))

# --- Plotting ---
plt.figure(figsize=(10, 6))
plt.plot(sizes, sbsa_times, label="SBSA Hypercube", marker='o')
plt.plot(sizes, flatlog_times, label="Flat Log Memory", marker='x')
plt.xlabel("Number of Memory Entries")
plt.ylabel("Retrieval Time (s)")
plt.title("Benchmark: SBSA Hypercube vs Flat Log Memory Retrieval")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("sbsa_vs_flat_memory_benchmark.png")
plt.show()
