import time
import matplotlib.pyplot as plt

# --- Simulated SBSA Memory ---
class SBSAStorageMock:
    def __init__(self):
        self.index = {}

    def store(self, key, content):
        self.index[key] = content

    def retrieve(self, key):
        return self.index.get(key, None)

# --- Simulated Flat Memory ---
class FlatEmbeddingMemory:
    def __init__(self):
        self.entries = []

    def store(self, label_scores, content):
        self.entries.append((label_scores, content))

    def retrieve(self, label_scores):
        for labels, content in self.entries:
            if labels == label_scores:
                return content
        return None

# --- Benchmark Function ---
def benchmark(memory, size=1000, sbsa=True):
    data = [
        (f"Sample text {i}", [round((i % 10) * 0.1, 2) for _ in range(4)])
        for i in range(size)
    ]

    start = time.time()

    # Store
    for text, scores in data:
        if sbsa:
            key = ("4KB", len(scores), round(sum(scores)/len(scores), 2), 1)
            memory.store(key, text)
        else:
            memory.store(scores, text)

    # Retrieve
    for text, scores in data:
        if sbsa:
            key = ("4KB", len(scores), round(sum(scores)/len(scores), 2), 1)
            memory.retrieve(key)
        else:
            memory.retrieve(scores)

    end = time.time()
    return end - start

# --- Run Benchmarks ---
sizes = [100, 500, 1000, 2000, 5000]
sbsa_times = []
flat_times = []

for N in sizes:
    sbsa_times.append(benchmark(SBSAStorageMock(), N, sbsa=True))
    flat_times.append(benchmark(FlatEmbeddingMemory(), N, sbsa=False))

# --- Plot Results ---
plt.figure(figsize=(10, 6))
plt.plot(sizes, sbsa_times, label="SBSA Encoder", marker='o')
plt.plot(sizes, flat_times, label="Flat Embedding List", marker='x')
plt.xlabel("Number of Observations")
plt.ylabel("Total Encode + Retrieve Time (s)")
plt.title("Benchmark: SBSA Encoder vs Flat Embedding Memory")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("sbsa_vs_flat_encoder_benchmark.png")
plt.show()
