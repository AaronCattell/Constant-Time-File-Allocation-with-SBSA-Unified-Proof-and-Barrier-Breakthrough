# sbsa_encoder_api.py

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sbsa_llm_memory_manager import SBSAHypercube
from transformers import pipeline
import numpy as np

app = FastAPI()
classifier = pipeline("zero-shot-classification")
memory = SBSAHypercube()

LABELS = ["navigation", "error", "request", "system"]
VERSION = 1

class ObservationInput(BaseModel):
    observation: str

@app.get("/")
def root():
    return {"message": "SBSA Neural Encoder API is running."}

@app.post("/encode")
def encode_memory(input: ObservationInput):
    global VERSION
    try:
        result = classifier(input.observation, candidate_labels=LABELS)
        scores = result["scores"]

        size_class = "4KB" if len(input.observation) > 40 else "2KB"
        thickness = len(scores)
        width = round(float(np.mean(scores)), 2)

        memory.store_memory(size_class, thickness, width, VERSION, input.observation)

        return {
            "stored_at": {
                "size_class": size_class,
                "thickness": thickness,
                "width": width,
                "version": VERSION
            },
            "content": input.observation
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/retrieve")
def retrieve_memory(size_class: str, thickness: int, width: float, version: int):
    try:
        result = memory.retrieve_memory(size_class, thickness, width, version)
        return {"result": result}
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))
