📘 
markdown
Copy
Edit
# SBSA Neural Encoder API

This project provides a FastAPI-powered API that encodes observations from a neural network into a structured SBSA Hypercube memory system. It bridges deep learning with symbolic memory using 4D memory geometry.

---

## 📦 Components

- `sbsa_encoder_api.py` — FastAPI server
- `sbsa_encoder_client.py` — Python client to test it
- `sbsa_llm_memory_manager.py` — SBSA memory logic (must be in the same directory)

---

## 🧠 What It Does

- Accepts an `observation` string (e.g., system logs, thoughts)
- Uses a HuggingFace `zero-shot-classification` model to generate a set of scores
- Maps those scores to SBSA coordinates:
  - **size_class** (slot)
  - **thickness** (depth / label count)
  - **width** (mean score)
  - **version** (global version tag)
- Stores the observation in SBSA Hypercube memory

---

## 🚀 Running the API

```bash
pip install fastapi uvicorn transformers
uvicorn sbsa_encoder_api:app --reload
🔌 Calling the API
POST /encode
Encodes and stores an observation.

json

{
  "observation": "System rebooted due to error."
}
GET /retrieve
Retrieve memory at SBSA coordinates.

http

GET /retrieve?size_class=2KB&thickness=4&width=0.45&version=1
🧪 Testing Locally

bash

python sbsa_encoder_client.py
📂 Optional Enhancements
Save memory to disk as JSON or SQLite

Add search/indexing by tag or timestamp

Use embeddings from other models (e.g., OpenAI, BERT)

Inspired by your SBSA architecture — powering neural-symbolic memory at scale.