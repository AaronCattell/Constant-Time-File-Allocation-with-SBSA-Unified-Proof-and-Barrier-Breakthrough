# sbsa_encoder_client.py

import requests

BASE_URL = "http://127.0.0.1:8000"

# Observation to encode
observation = {
    "observation": "System experienced a thermal spike in core module."
}

# Encode and store memory
resp = requests.post(f"{BASE_URL}/encode", json=observation)
print("[ENCODE]", resp.status_code, resp.json())

# Optional: retrieve the stored memory with known coordinates
retrieve_params = {
    "size_class": "4KB",
    "thickness": 4,
    "width": 0.5,
    "version": 1
}

resp = requests.get(f"{BASE_URL}/retrieve", params=retrieve_params)
print("[RETRIEVE]", resp.status_code, resp.json())
