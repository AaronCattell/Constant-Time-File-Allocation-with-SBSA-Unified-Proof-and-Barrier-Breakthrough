# SBSA Storage Layer

A prototype SBSA Hypercube-based filesystem logic that stores and retrieves content using spatial coordinates.

## Coordinates
- X: Size class slot (e.g. 2KB → 1)
- Y: Thickness (quantized depth)
- Z: Width (span of logic/memory)
- W: Version (fork or backup)

## Files

- `sbsa_storage_layer.py`: Main storage interface
- `example_sbsa_storage.py`: Demo: store, retrieve, list

## Usage

```bash
python example_sbsa_storage.py
```
