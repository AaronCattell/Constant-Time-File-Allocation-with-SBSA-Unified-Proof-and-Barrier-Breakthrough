# example_sbsa_storage.py

from sbsa_storage_layer import SBSAStorage

store = SBSAStorage()

# Store example files
key1 = store.store_file("report.txt", "SBSA storage report content.", "2KB", 10.3, 1.25, 0)
key2 = store.store_file("log.txt", "System log for analysis.", "4KB", 15.0, 2.8, 1)

# Retrieve and print
print("[File 1]", store.get_file("2KB", 10.3, 1.25, 0))
print("[File 2]", store.get_file("4KB", 15.0, 2.8, 1))

# List all indexed files
print("\n[All Indexed Files]")
for item in store.list_files():
    print(item)
