# sbsa_storage_layer.py

import os
import json
from datetime import datetime

size_classes = ['1KB', '2KB', '4KB', '8KB']
slots = {s: i for i, s in enumerate(size_classes)}
QUANTUM = 0.05
THICKNESS_QUANTUM = 5
MAX_VERSION = 10000

class SBSAStorage:
    def __init__(self, storage_path='storage'):
        self.index = {}
        self.storage_path = storage_path
        os.makedirs(self.storage_path, exist_ok=True)

    def quantize(self, value, quantum):
        return round(value / quantum) * quantum

    def map_key(self, size_class, thickness, width, version):
        slot = slots[size_class]
        width_q = self.quantize(width, QUANTUM)
        thickness_q = int(self.quantize(thickness, THICKNESS_QUANTUM))
        if not (0 <= version <= MAX_VERSION):
            raise ValueError("Invalid version")
        return (slot, thickness_q, width_q, version)

    def store_file(self, file_name, content, size_class, thickness, width, version):
        key = self.map_key(size_class, thickness, width, version)
        path = os.path.join(self.storage_path, f"{key}.data")
        meta = {
            "name": file_name,
            "created": datetime.utcnow().isoformat(),
            "tags": [],
            "path": path
        }
        with open(path, "w") as f:
            f.write(content)
        self.index[key] = meta
        return key

    def get_file(self, size_class, thickness, width, version):
        key = self.map_key(size_class, thickness, width, version)
        if key not in self.index:
            return None
        path = self.index[key]['path']
        with open(path, "r") as f:
            return f.read()

    def list_files(self):
        return [{"key": k, **v} for k, v in self.index.items()]
