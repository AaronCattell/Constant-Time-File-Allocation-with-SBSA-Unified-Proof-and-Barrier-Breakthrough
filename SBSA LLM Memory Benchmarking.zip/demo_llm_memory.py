from sbsa_memory import SBSAMemory

memory = SBSAMemory(slots=["Fact", "Message", "Plan"])

# Simulate memory writes from an LLM agent
memory.write("Plan", 0, 1.5, {"prompt": "Summarize task", "response": "Send email"})
memory.write("Message", 0, 2.0, {"from": "user", "text": "What is my plan?"})

# Memory recall
print(memory.read("Plan", 0, 1.5))
print(memory.read("Message", 0, 2.0))
