import os
import json
from pathlib import Path

class SBSAMemory:
    def __init__(self, memory_root="sbsa_memory", slots=None):
        self.root = Path(memory_root)
        self.slots = {s: i for i, s in enumerate(slots or ["Fact", "Thought", "Plan"])}

    def get_path(self, slot, thickness, width):
        slot_id = self.slots.get(slot, 0)
        return self.root / f"slot_{slot_id}" / f"layer_{thickness}" / f"mem_{width}.json"

    def write(self, slot, thickness, width, payload):
        path = self.get_path(slot, thickness, width)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(payload, f)

    def read(self, slot, thickness, width):
        path = self.get_path(slot, thickness, width)
        if not path.exists():
            raise FileNotFoundError(f"No memory found at: {path}")
        with open(path, "r") as f:
            return json.load(f)
