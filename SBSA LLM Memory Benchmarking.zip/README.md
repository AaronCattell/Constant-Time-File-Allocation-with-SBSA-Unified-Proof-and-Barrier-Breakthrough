# 🧠 LLMs + SBSA = Constant-Time Memory for AI

This demo shows how to use SBSA (Size-Based Slot Allocation) to give an LLM agent fast, logical memory storage.

Each memory is stored as:
- slot = memory type (Fact, Plan, Message)
- thickness = thread or agent ID
- width = time, score, or float key

## 🚀 How to Use

1. Run `demo_llm_memory.py`:

```bash
python demo_llm_memory.py
```

2. Output:

```
{'prompt': 'Summarize task', 'response': 'Send email'}
{'from': 'user', 'text': 'What is my plan?'}
```

## 🧠 Why It Works

No need for indexes, vector search, or graph memory.  
SBSA gives constant-time ($O(1)$) addressing.

Great for:
- Autonomous agents
- Hybrid memory systems
- Symbolic AI layers

MIT License — by Aaron Cattell
