import time
import json
import matplotlib.pyplot as plt
from pathlib import Path

class SBSAMemory:
    def __init__(self, memory_root="sbsa_memory_benchmark", slots=None):
        self.root = Path(memory_root)
        self.slots = {s: i for i, s in enumerate(slots or ["Fact", "Thought", "Plan"])}

    def get_path(self, slot, thickness, width):
        slot_id = self.slots.get(slot, 0)
        return self.root / f"slot_{slot_id}" / f"layer_{thickness}" / f"mem_{width}.json"

    def write(self, slot, thickness, width, payload):
        path = self.get_path(slot, thickness, width)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(payload, f)

    def read(self, slot, thickness, width):
        path = self.get_path(slot, thickness, width)
        if not path.exists():
            raise FileNotFoundError(f"Missing memory at {path}")
        with open(path, "r") as f:
            return json.load(f)

# --- Benchmarking ---
def benchmark_sbsa_memory(n=1000):
    memory = SBSAMemory()
    write_times, read_times = [], []

    # Measure writes
    for i in range(n):
        start = time.perf_counter()
        memory.write("Plan", 0, i + 0.1, {"index": i, "task": "compute"})
        write_times.append(time.perf_counter() - start)

    # Measure reads
    for i in range(n):
        start = time.perf_counter()
        memory.read("Plan", 0, i + 0.1)
        read_times.append(time.perf_counter() - start)

    print(f"Average write time: {sum(write_times)/n:.6f} seconds")
    print(f"Average read time: {sum(read_times)/n:.6f} seconds")

    # Plot
    plt.figure(figsize=(10, 6))
    plt.plot(write_times, label="Write Time (s)", color="green")
    plt.plot(read_times, label="Read Time (s)", color="blue")
    plt.xlabel("Task Index")
    plt.ylabel("Time (seconds)")
    plt.title("SBSA LLM Memory Write vs Read Performance")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("sbsa_llm_memory_benchmark.png")
    plt.show()

# Run benchmark
if __name__ == "__main__":
    benchmark_sbsa_memory()
