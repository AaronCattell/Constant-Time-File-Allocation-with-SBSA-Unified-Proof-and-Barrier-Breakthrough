import heapq
import time
from sbsa_storage import SBSAStorage

size_classes = ['Low', 'Medium', 'High', 'Critical']
sbsa = SBSAStorage(size_classes)

# Simulated tasks: (priority, layer, time_slot)
tasks = [("High", 1, i * 0.1) for i in range(10000)]

print("Benchmarking with 10,000 tasks...")

# SBSA write benchmark
start = time.time()
for t in tasks:
    sbsa.write(*t, "task payload")
sbsa_duration = time.time() - start
print(f"SBSA time: {sbsa_duration:.4f} sec")

# Heap insert benchmark
heap = []
start = time.time()
for t in tasks:
    heapq.heappush(heap, (t[2], t))
heap_duration = time.time() - start
print(f"Heap time: {heap_duration:.4f} sec")

print(f"Speedup: {heap_duration / sbsa_duration:.1f}× faster using SBSA")
