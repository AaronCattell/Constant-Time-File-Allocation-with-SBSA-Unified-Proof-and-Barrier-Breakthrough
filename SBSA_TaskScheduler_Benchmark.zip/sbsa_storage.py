import os

class SBSAStorage:
    def __init__(self, size_classes):
        self.slots = {cls: i for i, cls in enumerate(size_classes)}

    def get_path(self, size_class, thickness, width):
        if size_class not in self.slots:
            raise ValueError(f"Invalid size class: {size_class}")
        slot = self.slots[size_class]
        return f"storage/slot_{slot}/layer_{thickness}/file_{width}.txt"

    def write(self, size_class, thickness, width, content):
        path = self.get_path(size_class, thickness, width)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            f.write(content)
