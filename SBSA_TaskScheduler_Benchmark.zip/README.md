# ⚙️ SBSA vs Heap Benchmark — Task Scheduler Performance

This benchmark compares SBSA (Size-Based Slot Allocation) to Python's built-in `heapq` as a method for scheduling or storing tasks with priority and timing.

---

## 📦 Included

- `sbsa_storage.py` – core SBSA mapping to disk-backed files
- `benchmark_sbsa_vs_heap.py` – runs inserts using both SBSA and heap
- `sbsa_vs_heap_benchmark.png` – auto-generated chart after running
- `storage/` – SBSA output folder (auto-created)

---

## ▶️ How to Run

Install required library:
```bash
pip install matplotlib


Then run the benchmark:

python benchmark_sbsa_vs_heap.py


📊 What It Does
Creates simulated task entries like:

("High", 1, 0.1)
("High", 1, 0.2)
...


Writes them using:

SBSA → mapped to: storage/slot/layer/file.txt

Heap → stored in heapq as (time, task) tuples

Benchmarks insert speed across 100–10,000 tasks

📈 Example Output Chart
After running, the script generates:

sbsa_vs_heap_benchmark.png

Showing time taken per insert strategy.


💡 Why SBSA?
📌 Constant-time addressing (O(1))

🗂️ Real filesystem output (not just memory structures)

🧠 No comparisons, no balancing — just slot, layer, and width



🧠 Use Cases
Task queues

Message schedulers

Real-time logs

Event buffers




📜 License
MIT — created by Aaron Cattell with support from ChatGPT

---



