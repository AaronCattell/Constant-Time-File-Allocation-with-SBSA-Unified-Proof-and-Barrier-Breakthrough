from sbsa_storage import SBSAStorage

size_classes = ['1KB', '2KB', '4KB', '8KB', '16KB', '32KB']
sbsa = SBSAStorage(size_classes)

# Write
sbsa.write('4KB', 2, 3.5, "This is a file saved with SBSA.")

# Read
content = sbsa.read('4KB', 2, 3.5)
print("Read from SBSA:", content)
