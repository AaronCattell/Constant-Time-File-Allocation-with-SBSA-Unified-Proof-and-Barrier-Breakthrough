# 📘 How to Use SBSA Storage Layer (Python Version)

This is a simple implementation of the SBSA model with disk-backed storage using directories and files.

---

## 📂 Files

- `sbsa_storage.py` — Core logic: maps size class, thickness, and width to file paths
- `main.py` — Demo script: writes and reads from storage
- `storage/` — Auto-generated on write

---

## ▶️ Run the Example

```bash
python main.py

Output:
Read from SBSA: This is a file saved with SBSA.

Files created:
storage/slot_2/layer_2/file_3.5.txt

🧠 What It Does
Slot is determined by the size class

Thickness is a layer inside the slot

Width is used to distinguish files within that layer

This allows deterministic O(1)-style storage addressing.

📜 License
MIT — Created by Aaron Cattell

---


