from sbsa import map_file

# Basic insertion examples
print("Inserting file_a at 2KB:", map_file('2KB', 0, 1.0))
print("Inserting file_b at 4KB:", map_file('4KB', 1, 2.5))
