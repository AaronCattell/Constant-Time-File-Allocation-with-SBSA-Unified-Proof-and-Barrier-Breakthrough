from sbsa import map_file

# Trigger error for invalid size class
try:
    print(map_file('64KB', 0, 1.0))  # Not defined in class list
except ValueError as e:
    print("Caught error:", e)
