from sbsa import map_file

# Show continuous width differences
print("Width 1.0:", map_file('16KB', 0, 1.0))
print("Width 2.5:", map_file('16KB', 0, 2.5))
print("Width 3.75:", map_file('16KB', 0, 3.75))
