from sbsa import map_file

# Demonstrate multiple layers (thickness)
print("Layer 0:", map_file('8KB', 0, 1.0))
print("Layer 1:", map_file('8KB', 1, 1.0))
print("Layer 2:", map_file('8KB', 2, 1.0))
