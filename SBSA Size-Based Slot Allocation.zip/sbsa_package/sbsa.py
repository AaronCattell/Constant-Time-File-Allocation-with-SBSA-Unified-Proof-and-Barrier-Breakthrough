size_classes = ['1KB', '2KB', '4KB', '8KB']
slots = {s: i for i, s in enumerate(size_classes)}

def map_file(size_class, thickness, width):
    slot = slots.get(size_class, -1)
    if slot == -1:
        raise ValueError("Invalid size class")
    return (slot, thickness, width)

if __name__ == '__main__':
    print("Example mappings:")
    print(map_file('2KB', 5, 1))
    print(map_file('4KB', 3, 2.5))
