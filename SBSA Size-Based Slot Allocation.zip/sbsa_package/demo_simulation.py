import math

def simulate(n_files):
    btree = n_files * math.log2(n_files)
    sbsa = n_files
    print(f"B-tree steps: {btree:,.0f}")
    print(f"SBSA steps: {sbsa:,.0f}")
    print(f"Speedup: {btree / sbsa:.1f}x")

if __name__ == '__main__':
    simulate(1_000_000)
